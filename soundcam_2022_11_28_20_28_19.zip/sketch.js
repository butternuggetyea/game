var sine;
let cam
var freq = 400;
let mic;

let mySound;
function preload() {
  soundFormats('mp3', 'ogg', 'wav');
  mySound = loadSound('mouse.wav');
}
function setup() {
	createCanvas(440, 440);
  cam = createCapture(VIDEO);
    cam.hide();
    mic = new p5.AudioIn();
    mic.start();
	sine = new p5.SinOsc();
	//sine.start();

}

function draw() {
  	background(0);
    
  let vol = mic.getLevel();
let hertz = map( vol, 0, 1, height, 0);
sine.freq(hertz);
stroke(204);
for (var x = 0; x < height; x++) {
var angle = map(x, 0, width, 0, PI * hertz);
var sinValue = sin(angle) * 120;
line(x, 0, x, width + sinValue);

}
  image(cam, 0, 0, width, width * cam.height / cam.width);
  filter(DILATE);
}
function mouseClicked(){
    mySound.play();
}