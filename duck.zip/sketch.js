let img;
let backimg;
let coins;
let coin = 0
let coinposx = 100
let coinposy = 100

function preload(){
	img = loadImage("duckky.png")
    backimg = loadImage("duckky_background.jpg")
    coins = loadImage("coin.png")
}

function setup() {
	createCanvas(750, 550);
    image(backimg,0,0,750,55)
    colorMode(RGB, 255, 255, 255, 1);
	img.loadPixels()
    backimg.loadPixels()
    coins.loadPixels()
    textSize(15)
    textFont('Helvetica');
}
	
function draw() {
image(backimg,0,0,750,550)
image(coins,coinposx,coinposy,115,100)
image(img,mouseX-25,mouseY-20,50,50)
fill(227, 140, 45)
text(coin,700,40)
text("score:",650,40)
  if(mouseX <= coinposx+50 && mouseY <= coinposy+50 && mouseX >= coinposx && mouseY >= coinposy){
    coin += 1
    coinposx = int(random(10,730))
    coinposy = int(random(10,530))
  }
	
}
	
