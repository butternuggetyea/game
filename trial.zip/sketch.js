let world = 1
let level = 1
let posad = 1610
let poshight = 1000 - 40
let timeLog = 0
let ogposhight = 1000 - 50
let rightMove = 1600
let moveLeft = 10
let betas = 0
let L = 0
let R = 0

function preload(){
	backSky = loadImage("background.png")
    treeTwo = loadImage("cherryblossom.png")
    treeOne = loadImage("tree.png")
    island = loadImage("island.png")
    ground = loadImage("ground.png")
    portalB = loadImage("portalB.png")
    portalR = loadImage("portalR.png")
    evilback = loadImage("backgroundevil.png")
    slimeL = loadImage("slimeLeft.png")
    slimeR = loadImage("slimeRight.png")
}

function setup() {
	createCanvas(1660, 1080);
	colorMode(RGB, 255, 255, 255, 1);
	angleMode(DEGREES)
  	backSky.loadPixels()
    treeTwo.loadPixels()
    treeOne.loadPixels()
    island.loadPixels()
    ground.loadPixels()
    portalB.loadPixels()
    portalR.loadPixels()
    evilback.loadPixels()
    slimeL.loadPixels()
    slimeR.loadPixels()
}
  function ISLand(islandX=0,islandY=0,islandW=0,islandH=0){
  image(island,islandX,islandY,islandW,islandH)
  }
function cheTree(treeTwoX,treeTwoY){
  image(treeTwo,treeTwoX,treeTwoY,100,100)
}
function normTree(normTreeX,normTreeY){
  image(treeOne,normTreeX,normTreeY,100,100)
}

function portR(portalRX, portalRY){
image(portalR,portalRX,portalRY,75,100)
}

function portB(portalBX, portalBY){
image(portalB,portalBX,portalBY,75,100)  
}  

function treeSetTwo(){
new normTree(1300,500)
new normTree(1400,500)
new cheTree(1200,480)
new cheTree(100,110)
new normTree(1300,500)
new cheTree(850,890)
}  
function treeSetOne(){
new normTree(1300,100)
new cheTree(1200,100)
new normTree(1400,910)
new cheTree(1200,910)
new cheTree(100,910)
new normTree(1300,910)
new cheTree(850,910)
new cheTree(950,910)
new cheTree(10,910)
new normTree(500,910)
new cheTree(600,910)
}
function portalSetOne(){
new portR(470,493)
new portR(1150,85)
new portB(800,500) 
new portB(250,905)  
}

function portalSetTwo(){
new portR(900,890)
new portR(1140,495)
new portR(470,300)
new portR(1260,880)
new portB(1500,505) 
new portB(300,125)
new portB(705,885)
new portB(650,300)
}

function portalSetThree(){
new portR(1250,200)
new portB(330,890)

}

function draw() {
background(10,10,10)
image(backSky,0,0,1660,1080)
fill(0,0,255)
textSize(45)
keyInput()
  
  
  if (level === 1){
fill(0,0,0)
text ("Ah how peaceful.",200,100)
text ("Beautiful even, such a serene world",200,200)
if (posad === 260 && poshight === 1000 - 40){
  poshight =  600 - 50
  posad = 485
  moveLeft = 470
 }
if (posad === 815 && poshight === 550){
  poshight = 200 - 55
  posad = 1165
  moveLeft = 1155
}
if (posad === 1605 && poshight === 200 - 55){
  level = 2
  posad = 10
  poshight = 200 - 25 
  moveLeft = 10
} 
    
levelOneCollision()
new collisionbox(platposx=0,platposy=1000,platsizel=1660)
image(ground,0,-415,1660,1500)
new collisionbox(platposx=460,platposy=600, platsizel=400)
new ISLand(islandX=-40,islandY=90,islandW=1500,islandH=1000)
new collisionbox(platposx=1160,platposy=200, platsizel=600)
new ISLand(islandX=510,islandY=-320,islandW=1900,islandH=1000)
portalSetOne()
new treeSetOne()
  player()
} 

if (level === 2) {
fill(0,0,0)
text ("You know ... this ONE world is beautiful",400,100)
text ("in some ways, though I prefer a diffrent style.",400,200)
if (posad === 315 && poshight === 200 - 25){
  poshight =  600 - 50
  posad = 1155
  moveLeft = 1145
 }
if (posad === 1510 && poshight === 550){
  poshight =  1000 - 60
  posad = 915
  moveLeft = 10
  rightMove = 1060
 }
if (posad === 715 && poshight === 940){
  poshight =  350
  posad = 485
  moveLeft = 480
  rightMove = 1660
 }
if (posad === 660 && poshight === 350){
  poshight =  940
  posad = 1270
  moveLeft = 1255
  rightMove = 1660
 }
if (posad === 1660 && poshight === 940){
  level = 3
  posad = 0
  poshight = 1000 - 50 
  moveLeft = 10
  rightMove = 355
 }
new collisionbox(platposx=1360,platposy=1000,platsizel=300)
new ISLand(islandX=750,islandY=480,islandW=1500,islandH=1000)
new collisionbox(platposx=0,platposy=200, platsizel=250)
new ISLand(islandX=-550,islandY=-290,islandW=1500,islandH=1000)
new collisionbox(platposx=500,platposy=400, platsizel=350)
new ISLand(islandX=-40,islandY=-100,islandW=1500,islandH=1000)
new collisionbox(platposx=1160,platposy=600, platsizel=600)
new ISLand(islandX=450,islandY=90,islandW=2000,islandH=1000)
new collisionbox(platposx=800,platposy=1000, platsizel=300 )
new ISLand(islandX=200,islandY=480,islandW=1500,islandH=1000)
portalSetTwo()
treeSetTwo()
    player()
} 
  if (level === 3 ){
if (world === 1){
fill(0,0,0)
text ("One world is great and all but...",400,100)
text ("press E and Q to switch between worlds",200,800)
}
new collisionbox(platposx=1360,platposy=300,platsizel=300)
new ISLand(islandX=750,islandY=-210,islandW=1500,islandH=1000)
new collisionbox(platposx=0,platposy=1000, platsizel=400)  
new ISLand(islandX=-510,islandY=480,islandW=1500,islandH=1000)
player()
if (world === 1 && posad === 1615 && poshight === 250){
betas += 1
}
if(world === 2){ 
if (posad === 345 && poshight === 1000-50){
  poshight =  250
  posad = 1265
  rightMove = 1660 - 50
  moveLeft = 1255
 } 
image(evilback,0,0,1660,1080)
fill(0,0,0)
text ("TWO IS BETTER THAN ONE!!",400,300)
new collisionbox(platposx=1360,platposy=300,platsizel=300)
new ISLand(islandX=750,islandY=-210,islandW=1500,islandH=1000)
new collisionbox(platposx=0,platposy=1000, platsizel=400)  
new ISLand(islandX=-510,islandY=480,islandW=1500,islandH=1000)
portalSetThree()
player()
  }
if (betas >= 1){
  background(10,10,10)
text("End of beta",500,500) 
} 
  }
  


}

function keyTyped() {
if (key === 'e' && world === 1 && level === 3){
  world = 2 }
  if (key === 'q'){
 world = 1 
}
}

function keyPressed(){
  if(keyCode === LEFT_ARROW && level >= 2){
 level -= 1
  if (level === 2) {
  posad = 0
  poshight = 200 - 25
   }     
    if (level === 1){
posad = 1610
poshight = 1000 - 50 
    }
  if (level === 3) {
  posad = 0
  poshight = 1000 - 50 
   }     
}

  if(keyCode === RIGHT_ARROW && level <= 2){
  level += 1
   if (level === 2) {
  posad = 0
  poshight = 200 - 25    
}
         if (level === 1){
posad = 1610
poshight = 1000 - 50 
    }
        if (level === 3) {
  posad = 0
  poshight = 1000 - 50 
   }   
}

} 


function collisionbox(platposx=-10,platposy=-100,platsizel=0){
    fill(0,255,0)
  rect(platposx,platposy,platsizel,15)
  
}

function player(){
if(R === 1){
image(slimeR,posad,poshight,50,50)
}else{
image(slimeL,posad,poshight,50,50)
}
}


function player2(posAD,PosH){
 fill (255,0,0)
 square(posAD,PosH,50)
}

function keyInput(){
   if(key === 'a' && posad >= moveLeft && keyIsPressed === true){
posad -= 5
L = 1}else{
L=0
}
if (key ==='d'&& posad <=rightMove && keyIsPressed === true){
  posad +=5
R = 1  }else{
R=0
}
//if(key == ' ' && keyIsPressed === true){
//if(poshight >= ogposhight - 250){
  //poshight -= 5} else{
    //poshight = ogposhight    
//}
//} 
}
function levelOneCollision(){
  if (poshight<= 800 && posad  >= 460 && posad <= 960){
    ogposhight = 800 - 50
}
    if (poshight<= 600 && posad  >= 1160 && posad <= 1660){
    ogposhight = 600 - 50
}


}